Twin Cities Animal Rescue - Touchstone 3 Website

This folder contains four HTML pages, one external stylesheet, and local SVG illustrations. Open index.html in a browser to preview the site. All navigation links use relative paths within this folder.

The design uses forest green (#245342), terracotta (#9B4A2C), warm ivory (#F4EFE5), and charcoal (#26332D), with Arial and Georgia. The layout is mobile-first, uses Flexbox and CSS Grid, and includes responsive media queries.

The client materials did not provide verified statistics, service areas, office hours, partner names, or an approved video. The pages do not invent those details. The contact form is a front-end demonstration only and is not connected to a submission service. Replace the video placeholder and connect the form only with client-approved content and services before real publication.

The illustrations are generic original SVG artwork created for this class project; they do not depict specific available animals.

The ZIP includes a static visual preview in the accompanying Touchstone document. The official submission still needs the student's GitHub repository URL, hosted preview URL, and browser screenshot after publication.
